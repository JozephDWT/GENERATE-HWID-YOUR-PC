﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;


[assembly: AssemblyTitle("HWID")]
[assembly: AssemblyDescription("Jozeph.dwt by DEVELOPERS")]
[assembly: AssemblyCopyright("C# World")]
[assembly: AssemblyVersion("1.0")]
[assembly: AssemblyFileVersion("1.0")]
